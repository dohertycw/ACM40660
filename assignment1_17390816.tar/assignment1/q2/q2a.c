#include <stdio.h>

//Initialising a function to loop from 1 to 3.

int main(){
	int i;
	for(i=1; i<=3; i++){
		//Printing loop.
		printf("%d \n", i);
	}
	return 0;
}
